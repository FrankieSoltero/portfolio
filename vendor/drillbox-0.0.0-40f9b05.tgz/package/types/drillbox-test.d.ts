// Ambient types for the `drillbox:test` module that exercise check files import from.

declare module "drillbox:test" {
  export { describe, it, expect, beforeEach, afterEach } from "vitest";
}
