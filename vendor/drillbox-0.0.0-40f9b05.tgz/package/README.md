# drillbox

drillbox runs TypeScript and React coding exercises in the browser. It compiles the
learner's files, runs them inside a sandboxed iframe, and reports check results, compile
errors and console output back to the page that embeds it.

Status: **pre-release.** The library is built and tested locally only. It is not published
on npm and has no public repository yet. Its interface may still change.

## Terms

- **Host page:** your web page, the one that embeds drillbox.
- **Frame:** the sandboxed `<iframe>` in which the learner's code runs. drillbox creates a
  fresh frame for every run.
- **Exercise:** a JSON object holding the learner's files, the check files and a few
  settings. See [Exercise format](#exercise-format).
- **Check file:** a test file that exercises the learner's code, written with `describe`,
  `it` and `expect`. The learner is not meant to see check files.
- **Run:** one attempt to compile and execute an exercise. A run has a mode: `preview`
  renders the exercise's entry file in the frame; `checks` runs the check files.

## What is in the package

| Import                   | Runs where                | What it is                                                                                                                           |
| ------------------------ | ------------------------- | ------------------------------------------------------------------------------------------------------------------------------------ |
| `drillbox`               | host page                 | The engine: `createSandbox`, the run summary types and the limits                                                                    |
| `drillbox/frame`         | Node, at build time       | `buildFrame`, which writes the self-contained frame page, and `jsAdapter`                                                            |
| `drillbox/schema`        | anywhere                  | The exercise format: TypeScript types, a zod schema and `parseExercise`. The JSON Schema is in `schema/exercise.schema.json`         |
| `drillbox/vitest`        | Node, in your test runner | A shim that lets the same check files run under vitest. See [Writing checks](#writing-checks)                                        |
| `drillbox/workspace`     | host page (React 19+)     | The `Workspace` React component: a code editor with file tabs, a live preview, the checks and a console. See [Workspace](#workspace) |
| `drillbox/workspace.css` | host page                 | The workspace's stylesheet and default theme. See [Theming](#theming)                                                                |

The JavaScript/TypeScript adapter and the React pack have no import of their own: they
ship only inside the prebuilt frame scripts that `buildFrame` puts into the frame page
(`jsAdapter({ react: true })` picks the one with the React pack).

## Usage

Two steps. At build time, write the frame page with `buildFrame` and serve it from your
site with the response header below. In the host page, create a sandbox with
`createSandbox` and call `run`.

```ts
// build-frame.mjs: run with Node when you build your site.
import { writeFileSync } from "node:fs";
import { buildFrame, jsAdapter } from "drillbox/frame";
writeFileSync("public/frame.html", buildFrame({ adapters: [jsAdapter({ react: true })] }));
```

```ts
// Host page.
import { createSandbox } from "drillbox";
import { parseExercise } from "drillbox/schema";

const sandbox = createSandbox({
  container: document.getElementById("preview")!,
  frameUrl: new URL("/frame.html", location.href).href,
});
const parsed = parseExercise(await (await fetch("/exercises/like-button.json")).json());
if (parsed.ok) {
  const summary = await sandbox.run({ exercise: parsed.exercise, mode: "checks" });
  console.log(summary.status, `${summary.passed} of ${summary.total} checks passing`);
}
```

What to know:

- Serve `frame.html` with the response header
  `Content-Security-Policy: sandbox allow-scripts; frame-ancestors 'self'`:
  - `sandbox allow-scripts` makes the browser sandbox the page (scripts only, opaque
    origin) even when a page embeds it without the `sandbox` attribute or opens it directly;
  - `frame-ancestors 'self'` lets only pages of your own site embed it.

  The frame page also refuses to start unless it is sandboxed (see
  [Threat model](#threat-model)); the header is a second layer. The other way is to serve
  `frame.html` from a separate origin that holds nothing else (for example a subdomain of
  its own); there, name your host page's origin in `frame-ancestors` instead of `'self'`.
  `npm run demo` serves it with the header.

- By default `buildFrame` also puts a small stylesheet into the frame page, so the learner's
  page starts from readable defaults: a light colour scheme, a 16 px margin, a 15 px system
  font, and form controls that use the page's font. Pass `baseStyles: false` to leave it
  out.
- `frameUrl` must point at that frame page. The frame is always loaded by URL, never
  through `srcdoc`. The frame page carries its own Content-Security-Policy in a `<meta>`
  tag (a browser rule that limits what a page may load and run). If your server adds a
  Content-Security-Policy header to every response, make sure that header's policy does
  not restrict `script-src` for `frame.html`: the browser applies both policies, and a
  stricter `script-src` blocks the frame's inline scripts.
- `createSandbox` takes `container` (the element the iframe goes into), `frameUrl`, and
  optionally `hidden: true` (an invisible frame, for checks), `title` (the iframe's
  accessible name) and `limits` (see [Limits](#limits)).
- `run` never rejects. It resolves with a summary: `status`, `mode`, `passed`, `failed`,
  `total`, `results` (one entry per check), `diagnostics` (compile errors) and `issues`
  (validation problems). The host computes the counts from the results it received.
- An optional second argument to `run`, `onEvent(event)`, receives each message of the run
  as it arrives: `console`, `runtime-error`, `compile-error`, `check-result` and
  `run-complete`.
- Starting a new run removes the previous frame. `stop()` ends the current run and removes
  any preview. `dispose()` does the same, and every later `run` resolves `stopped`.
- Diagnostic `line` and `column` numbers are 1-based. Either can be `null` when unknown.
- Keep the learner's code in the host page (or your own storage), never only in the frame.
  A frozen frame cannot be recovered; see [Threat model](#threat-model).

Run statuses:

| `status`               | Meaning                                                                                                                          |
| ---------------------- | -------------------------------------------------------------------------------------------------------------------------------- |
| `completed`            | The run finished. In `checks` mode, read `results`. In `preview` mode the preview stays on screen until the next run or `stop()` |
| `compile-error`        | At least one file did not compile; read `diagnostics`                                                                            |
| `invalid-exercise`     | The request failed validation; read `issues`. No frame was created                                                               |
| `unsupported-language` | The frame page was built without an adapter for the exercise's `language`                                                        |
| `timeout`              | The frame stopped answering, or the run went over the run time limit                                                             |
| `stopped`              | `stop()` or `dispose()` was called, or a newer run replaced this one                                                             |
| `unavailable`          | The frame did not report that it was ready (within 5 s by default), or the iframe could not be created                           |

`npm run demo` builds two complete host pages and serves them at `http://127.0.0.1:4173`:
`demo/app.tsx` at `/` uses the [Workspace](#workspace), and `demo/main.ts` at
`/harness.html` calls `createSandbox` directly from plain DOM code (the browser tests drive
it).

## Workspace

`drillbox/workspace` is a ready-made exercise screen built on the engine. Its `Workspace`
React component shows a code editor (CodeMirror 6) with one tab per file, a live preview of
the entry file, a `RUN CHECKS` button with the check results, a list of compile problems
and a console. `drillbox/workspace.css` styles it; you can re-skin it through CSS custom
properties (see [Theming](#theming)).

What it needs:

- `react` and `react-dom` 19 or later. They are optional peer dependencies of drillbox,
  needed only by `drillbox/workspace`; the other entries do not use them.
- The CodeMirror packages (`@codemirror/*` and `@lezer/highlight`) are regular
  dependencies and install with drillbox.
- A frame page built with `buildFrame` and served as described under [Usage](#usage). The
  preview renders the entry file as a React component, so the frame needs the React pack
  (`jsAdapter({ react: true })`).

```tsx
// drill.tsx: a client component of the host. `save` is your own storage function.
"use client";
import { Workspace } from "drillbox/workspace";
import type { Exercise } from "drillbox/schema";

type DrillProps = { exercise: Exercise; saved?: Record<string, string> };

export function Drill({ exercise, saved }: DrillProps) {
  return (
    <Workspace
      exercise={exercise}
      frameUrl="/frame.html"
      initialFiles={saved}
      onChange={(files) => save(exercise.id, files)}
      onResult={(summary) => console.log(summary.status, summary.passed, summary.total)}
    />
  );
}
```

Import the stylesheet once, in the host's client entry or root layout:
`import "drillbox/workspace.css";` (the package ships a type stub for it, so TypeScript
accepts the import). The CSS import needs a bundler that handles CSS files. Otherwise,
serve `node_modules/drillbox/dist/workspace/workspace.css` with a `<link>` (the demo copies
it into its own stylesheet). A complete host is `demo/app.tsx`.

| Prop             | Required | Meaning                                                                                                                                                                                                                                        |
| ---------------- | -------- | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `exercise`       | yes      | The exercise; validate it with `parseExercise` first. Its `id` is its identity: a new `id` opens the new exercise with fresh state. To load a changed exercise under the same `id`, remount the component (for example with a React `key`)     |
| `frameUrl`       | yes      | URL of the frame page; relative URLs such as `/frame.html` work                                                                                                                                                                                |
| `initialFiles`   | no       | Saved code by path, for example what `onChange` delivered earlier. Read when an exercise opens (on mount and when `exercise.id` changes). Only visible, editable files of the exercise are taken; other keys and non-string values are ignored |
| `onChange`       | no       | `(files) => void`. Called after every edit and after a reset with the code of every visible, editable file (path to code). Read-only and hidden files are not included                                                                         |
| `onResult`       | no       | `(summary) => void`. Called once per finished checks run with the engine's run summary (see [Usage](#usage)). Not called for previews, nor for a run that a reset, a new exercise or unmounting abandoned                                      |
| `labels`         | no       | Replaces any of the default strings, for example to translate them. See [Labels](#labels)                                                                                                                                                      |
| `className`      | no       | Extra class names for the root element, beside `dbx-workspace`                                                                                                                                                                                 |
| `previewDelayMs` | no       | Time from the last edit to the preview running again. Default 700 ms. A value that is not a finite number of at least 0 uses the default                                                                                                       |
| `cspNonce`       | no       | Nonce for the `<style>` elements CodeMirror adds to the page, for a host whose Content-Security-Policy restricts `style-src`. See [Style policy](#style-policy)                                                                                |

The callbacks may be new functions on every render; the workspace always calls the latest
ones. If a callback throws, the workspace keeps working and passes the error to the
browser's `reportError` (it shows up in the console as an uncaught error).

**It stores nothing.** The workspace uses no `localStorage`, `sessionStorage`, cookies or
IndexedDB. The host keeps the learner's code: save what `onChange` delivers, and pass it
back as `initialFiles` when the page opens again. `demo/app.tsx` does this with
`sessionStorage`. Keep the code in the host page even while the workspace is open: a frozen
sandbox cannot give it back.

How it behaves:

- **Files.** One tab per file of the exercise that is not `hidden`: the entry file first,
  then the others by path. A `readOnly` file shows `READ-ONLY` on its tab and cannot be
  edited. Hidden files have no tab but are still sent into the frame (see
  [Exercise format](#exercise-format)).
- **Two sandboxes.** The preview runs in a visible sandbox: when an exercise opens, and
  again about 700 ms after the last edit (`previewDelayMs`). The checks run in a second,
  hidden sandbox when the learner presses `RUN CHECKS`; the button reads `RUNNING…` and
  does nothing until they finish. It is marked `aria-disabled="true"` rather than disabled,
  so a button that has keyboard focus keeps it during the run.
- **Results.** Each check shows the word `PASS` or `FAIL` and its name, and the checks bar
  shows `<passed> OF <total> PASSING` or `ALL CHECKS PASSING`. A failure message shows its
  first paragraph (up to the first blank line); the rest, such as Testing Library's dump of
  the page, is behind a `DETAILS` toggle.
- **Compile errors.** When a file does not compile, in either sandbox, a `PROBLEMS` list
  appears under the editor with one entry per error, written `file:line:column message`
  (line and column are 1-based). Clicking an entry selects that file and, when the error has
  a line number, moves the caret there; problems in files without a tab (hidden files,
  check files) are listed as plain text. The status line reads `COMPILE ERROR`. Once a
  preview compiles the code again, the problems in the exercise's files clear, and a checks
  result that ended in a compile error goes back to `NOT RUN YET`. Problems in check files,
  which a preview does not compile, stay until the next checks run, a reset, a new
  exercise, or a preview that fails to compile (its problems replace the list).
- **Checks that could not run.** When a checks run ends `invalid-exercise` or
  `unsupported-language`, the checks bar reads `COULD NOT RUN` and the `PROBLEMS` list
  shows the summary's `issues`, one per line, as plain text.
- **Console.** Output from both sandboxes, oldest first, at most 200 entries. A new preview
  replaces the earlier preview output, and a new checks run the earlier checks output.
- **Reset.** `RESET CODE` is enabled once an editable file differs from the exercise. The
  first click turns it into `CLICK AGAIN TO RESET`; a second click within 4 s puts back the
  exercise's code, clears the results, problems and console, calls `onChange` and moves
  focus to the editor. Waiting 4 s or moving focus away cancels it.
- **Undo history.** Undo (Ctrl+Z or Cmd+Z) covers the learner's own typing. Code that comes
  from outside the editor (a reset, another exercise) starts a fresh history, so undo never
  brings back discarded code. Switching to another file's tab also starts a fresh history
  for that file.
- **Frozen sandbox.** When a run resolves `timeout` or `unavailable`, the workspace shows
  an alert (`The sandbox stopped responding. Close this tab and open the page again.`),
  disables both buttons and runs nothing more, even after the exercise changes. Unmounting
  the component disposes of both sandboxes.

The engine's documented limits apply to the workspace unchanged: in Firefox and Safari the
frame shares the page's thread, so runaway code can stall or freeze the whole page; a
frozen sandbox is not recovered; and the learner's code can read the checks and tamper with
their results, so treat results as feedback. See [Threat model](#threat-model).

`drillbox/workspace` also exports `useWorkspace`, the hook that holds the workspace's state
and runs both sandboxes, with its types, for hosts that want to draw their own UI.

### Server rendering and Next.js

- The entry is a client component: `drillbox/workspace` begins with `"use client"`, so a
  Next.js server component can render `<Workspace>` but cannot pass it functions; put the
  workspace (with its `onChange` and `onResult`) in a client component of your own, as above.
- Importing it on a server is safe: nothing touches the DOM at import or during render. The
  editor and both sandboxes start in effects, in the browser.
- `initialFiles` is read only on mount and when `exercise.id` changes. A host that restores
  saved code from browser storage must either render the workspace only after it has read
  the storage (below), or change the workspace's `key` when the saved code arrives. Reading
  the storage during render causes a hydration mismatch: the server has no storage.
- Import `drillbox/workspace.css` once, in the host's client entry or root layout.
- Serve `frame.html` with the sandbox header described under [Usage](#usage).

```tsx
// saved-drill.tsx: reads the saved code in an effect, then renders the workspace.
"use client";
import { useEffect, useState } from "react";
import { Workspace } from "drillbox/workspace";
import type { Exercise } from "drillbox/schema";

type Saved = { id: string; files?: Record<string, string> };

export function SavedDrill({ exercise }: { exercise: Exercise }) {
  const [saved, setSaved] = useState<Saved | null>(null);
  useEffect(() => setSaved({ id: exercise.id, files: loadSaved(exercise.id) }), [exercise.id]);
  if (saved?.id !== exercise.id) return null; // Storage not read yet for this exercise.
  return (
    <Workspace
      exercise={exercise}
      frameUrl="/frame.html"
      initialFiles={saved.files}
      onChange={(files) => save(exercise.id, files)}
    />
  );
}
```

In the example above, `loadSaved` and `save` are the host's own functions for reading and
writing its storage. Because the entry is a client module, use its other exports
(`DEFAULT_LABELS`, `useWorkspace`) from client components too: in a server component they
are references, not values.

### Accessibility

- Every control is reachable and usable from the keyboard, shows a focus outline
  (`--dbx-focus`) and is at least 44 px high. Results are the words `PASS` and `FAIL`, not
  only a colour.
- The file tabs follow the WAI-ARIA tabs pattern: Tab reaches the selected tab, and the
  Left and Right arrow keys (wrapping), Home and End select another file.
- In the editor, Tab indents. To leave the editor, press Escape, then Tab (or Shift+Tab)
  within two seconds.
- The console list can take focus, so it can be scrolled with the keyboard.
- The panel bars (`LIVE PREVIEW`, `PROBLEMS`, `CHECKS`, `CONSOLE`) are level-3 headings under
  the level-2 `WORKSPACE` title, so heading navigation reaches each panel.
- One `role="status"` element (`p.dbx-status`) announces `RUNNING…`, `COMPILE ERROR` and the
  checks summary. Its `data-state` attribute is `idle`, `running`, `done`, `compile-error`
  or `frozen`; when frozen it is empty, and the frozen message is announced once, by the
  `role="alert"` element. The stylesheet hides it visually except for `compile-error` (see
  [Theming](#theming)); a theme must not remove it: `display: none` would also hide it from
  screen readers.
- With `prefers-reduced-motion: reduce`, every transition and animation inside the
  workspace is off.
- In Safari, Tab skips buttons and links unless the user turns on full keyboard access;
  Option+Tab reaches them. See `docs/browser-notes.md`.

### Labels

Every visible string comes from `labels`. Pass any subset; the rest keep their defaults
(`DEFAULT_LABELS`, exported from `drillbox/workspace`). Values that are not strings are
ignored. The preview iframe's accessible name, `Live preview`, is fixed and not a label.

| Key             | Default                                                                   | Where                                                                   |
| --------------- | ------------------------------------------------------------------------- | ----------------------------------------------------------------------- |
| `workspace`     | `WORKSPACE`                                                               | Title, and the workspace's accessible name                              |
| `runChecks`     | `RUN CHECKS`                                                              | Checks button                                                           |
| `running`       | `RUNNING…`                                                                | Checks button, status line and checks bar during a run                  |
| `resetCode`     | `RESET CODE`                                                              | Reset button                                                            |
| `confirmReset`  | `CLICK AGAIN TO RESET`                                                    | Reset button after its first click                                      |
| `files`         | `Files`                                                                   | Accessible name of the tab list                                         |
| `readOnly`      | `READ-ONLY`                                                               | Tag on a read-only file's tab                                           |
| `codeEditor`    | `Code editor`                                                             | Editor's accessible name, followed by `: <path>`                        |
| `livePreview`   | `LIVE PREVIEW`                                                            | Preview panel bar                                                       |
| `checks`        | `CHECKS`                                                                  | Checks panel bar                                                        |
| `checkResults`  | `Check results`                                                           | Accessible name of the results list                                     |
| `details`       | `DETAILS`                                                                 | Toggle for the rest of a failure message                                |
| `noChecksYet`   | `NOT RUN YET`                                                             | Checks bar before a run                                                 |
| `passing`       | `{passed} OF {total} PASSING`                                             | Checks bar and status line; `{passed}` and `{total}` are filled in      |
| `allPassing`    | `ALL CHECKS PASSING`                                                      | Checks bar and status line when every check passes                      |
| `pass`          | `PASS`                                                                    | Badge of a passing check                                                |
| `fail`          | `FAIL`                                                                    | Badge of a failing check                                                |
| `console`       | `CONSOLE`                                                                 | Console panel bar and list name                                         |
| `problems`      | `PROBLEMS`                                                                | Problems bar and list name                                              |
| `compileError`  | `COMPILE ERROR`                                                           | Status line and checks bar                                              |
| `couldNotRun`   | `COULD NOT RUN`                                                           | Checks bar and status line when the last checks run could not start     |
| `frozen`        | `The sandbox stopped responding. Close this tab and open the page again.` | Alert once a sandbox froze                                              |
| `previewError`  | `The preview could not start.`                                            | Above the preview when it fails for a reason other than a compile error |
| `warningPrefix` | `Warning: `                                                               | Read by screen readers before a console warning (visually hidden)       |
| `errorPrefix`   | `Error: `                                                                 | Read by screen readers before a console error (visually hidden)         |

### Style policy

The workspace components set no `style` attributes; all of their styling is in
`workspace.css`. CodeMirror, however, adds `<style>` elements to the page while it runs. A
host whose Content-Security-Policy does not allow inline styles (`style-src` without
`'unsafe-inline'`) passes that policy's nonce as `cspNonce`, and CodeMirror puts it on its
style elements. CodeMirror also sets inline styles on a few of its own elements (sizes and
positions it computes, and `tab-size`, which `workspace.css` sets as well). A unit test
checks that the nonce reaches CodeMirror's style element; no browser test runs the
workspace under a strict `style-src` policy.

### Theming

Every class name the workspace's components emit starts with `dbx-`, from `dbx-workspace`
on the root element down (inside the editor, CodeMirror's own elements carry its `cm-`
classes). Every colour, font, font size, frame, radius, font weight and transition time in
`workspace.css` is a CSS custom property whose name starts with `--dbx-`, declared with its
default on `.dbx-workspace`. Spacing and layout sizes are not properties.

A theme sets new values with a selector more specific than `.dbx-workspace`. Setting them
on an ancestor such as `:root` has no effect, because the defaults on `.dbx-workspace`
itself win over inherited values.

```css
/* Either a class around the workspace ... */
.my-theme .dbx-workspace {
  --dbx-accent: #73eff7;
  --dbx-radius: 0;
}
/* ... or one passed through the className prop: <Workspace className="my-theme" /> */
.dbx-workspace.my-theme {
  --dbx-accent: #73eff7;
}
```

Notes:

- Theme the editor through the `--dbx-editor-*` and `--dbx-syn-*` properties, not by
  overriding CodeMirror's `.cm-*` selectors: the stylesheet's CodeMirror rules are specific
  enough to beat CodeMirror's own theme, so a plainer override loses to them.
- The status line (`p.dbx-status`) is visually hidden by default, but stays in the
  accessibility tree, because the checks bar already shows the same summary; only when
  `data-state="compile-error"` is it shown, in the label font and `--dbx-warn`.
- The preview area sets `color-scheme: light`, matching the frame's light document, so a
  theme whose `--dbx-preview-bg` is not white does not get an opaque white frame canvas.
- The workspace loads no fonts. Load the ones a theme names yourself (`@font-face`).
- A pixel font that ships only one weight: set `--dbx-weight-strong` and
  `--dbx-weight-medium` to `400`. The stylesheet sets `font-synthesis: none`, so the
  browser never fakes a bold.
- `demo/theme-8bit.css` is a worked example: the hybrid 8-bit skin of the demo page. It
  also holds the demo's page-shell rules (the `.demo-*` classes and `html`, `body`, `h1`),
  which are not part of the workspace. Its "Workspace variables" block sets every property.
  Its "Workspace overrides" block holds the rules no property covers, written as selector
  overrides on `dbx-` classes: no padding around the workspace and line height 1.6; no
  letter spacing on the pixel fonts; wider gaps and button padding; 52 px panel bars,
  checks summary and tabs, with tabs edge to edge, no underline on the selected one, the
  tab's focus ring drawn inside it and a full-size `READ-ONLY` tag; the checks summary in
  `--dbx-warn`; tighter check rows and badges, with no box around `PASS`; line height 1.2
  for the compile-error status line; an editor focus border drawn as `.dbx-editor::after`
  above CodeMirror's line-number gutter; and code line height 1.7.
- Class names, like the rest of the interface, may still change before a release; the
  custom properties are the intended way to theme.

| Property                   | Default                   | What it styles                                                                                                      |
| -------------------------- | ------------------------- | ------------------------------------------------------------------------------------------------------------------- |
| `--dbx-bg`                 | `#14161f`                 | Workspace background                                                                                                |
| `--dbx-panel`              | `#1c1f2b`                 | Panel and editor background                                                                                         |
| `--dbx-panel-raised`       | `#2a2f40`                 | Selected tab and a hovered problem                                                                                  |
| `--dbx-text`               | `#f2f3f5`                 | Main text                                                                                                           |
| `--dbx-text-dim`           | `#a9b1c2`                 | Secondary text: panel bars, status line, tabs, failure messages                                                     |
| `--dbx-rule`               | `#33394d`                 | Dividing rules: under bars and tabs, beside the gutter, above the results                                           |
| `--dbx-rule-width`         | `1px`                     | Width of those rules                                                                                                |
| `--dbx-list-rule`          | `#2a2f40`                 | The 2 px line between check rows                                                                                    |
| `--dbx-accent`             | `#8ab4ff`                 | Workspace title, selected tab's underline, `DETAILS` toggle                                                         |
| `--dbx-preview-bg`         | `#ffffff`                 | Preview area behind the frame                                                                                       |
| `--dbx-pass`               | `#7ddc8a`                 | `PASS` badge                                                                                                        |
| `--dbx-fail`               | `#b3364a`                 | `FAIL` badge, armed reset button, frozen alert, preview error, problem and console-error markers, unmatched bracket |
| `--dbx-fail-text`          | `#ffffff`                 | Text on `--dbx-fail`                                                                                                |
| `--dbx-warn`               | `#ffd166`                 | Console warning marker and tint                                                                                     |
| `--dbx-primary-bg`         | `#7ddc8a`                 | `RUN CHECKS` background                                                                                             |
| `--dbx-primary-text`       | `#10131a`                 | `RUN CHECKS` text                                                                                                   |
| `--dbx-secondary-bg`       | `#33394d`                 | `RESET CODE` background                                                                                             |
| `--dbx-secondary-text`     | `#f2f3f5`                 | `RESET CODE` text                                                                                                   |
| `--dbx-focus`              | `#ffd166`                 | Focus outline                                                                                                       |
| `--dbx-frame`              | `none`                    | A `box-shadow` value drawn around panels, buttons and the frozen alert                                              |
| `--dbx-radius`             | `6px`                     | Corner radius                                                                                                       |
| `--dbx-font-title`         | `system-ui, sans-serif`   | Workspace title, buttons, badges                                                                                    |
| `--dbx-font-label`         | `system-ui, sans-serif`   | Tabs, panel bars, status line, checks summary, `DETAILS` toggle                                                     |
| `--dbx-font-body`          | `system-ui, sans-serif`   | Everything else, such as check names                                                                                |
| `--dbx-font-code`          | `ui-monospace, monospace` | Editor, problems, failure messages, console                                                                         |
| `--dbx-title-size`         | `14px`                    | Workspace title                                                                                                     |
| `--dbx-label-size`         | `14px`                    | Text in the label font                                                                                              |
| `--dbx-body-size`          | `14px`                    | Body text                                                                                                           |
| `--dbx-button-size`        | `14px`                    | Buttons                                                                                                             |
| `--dbx-badge-size`         | `12px`                    | `PASS` and `FAIL` badges                                                                                            |
| `--dbx-code-size`          | `14px`                    | Editor text                                                                                                         |
| `--dbx-detail-size`        | `13px`                    | Problems, failure messages, console                                                                                 |
| `--dbx-weight-strong`      | `600`                     | Title, buttons, bars, status line, checks summary, badges, alerts                                                   |
| `--dbx-weight-medium`      | `500`                     | Tabs, `DETAILS` toggle                                                                                              |
| `--dbx-transition`         | `120ms`                   | Duration of every transition (button hover and press, tab colour)                                                   |
| `--dbx-editor-gutter-bg`   | `#1c1f2b`                 | Line-number gutter background                                                                                       |
| `--dbx-editor-gutter-text` | `#8a94aa`                 | Line numbers                                                                                                        |
| `--dbx-editor-active-line` | `#222634`                 | Current line and its line number                                                                                    |
| `--dbx-editor-selection`   | `#2f4166`                 | Selected text                                                                                                       |
| `--dbx-editor-caret`       | `#ffd166`                 | Caret                                                                                                               |
| `--dbx-editor-bracket`     | `#7c869c`                 | Outline around the bracket matching the one at the caret                                                            |
| `--dbx-syn-keyword`        | `#ff9d7a`                 | Keywords, `null`, `true` and `false`                                                                                |
| `--dbx-syn-string`         | `#7ddc8a`                 | Strings and regular expressions                                                                                     |
| `--dbx-syn-comment`        | `#8a94aa`                 | Comments (also set in italics)                                                                                      |
| `--dbx-syn-number`         | `#ffd166`                 | Numbers                                                                                                             |
| `--dbx-syn-type`           | `#8ab4ff`                 | Type, class and namespace names                                                                                     |
| `--dbx-syn-function`       | `#8ab4ff`                 | Names of called or defined functions and methods                                                                    |
| `--dbx-syn-tag`            | `#ff9d7a`                 | JSX tag names and angle brackets                                                                                    |
| `--dbx-syn-attribute`      | `#ffd166`                 | JSX attributes and property names                                                                                   |
| `--dbx-syn-punctuation`    | `#a9b1c2`                 | Punctuation, brackets and operators                                                                                 |

## Exercise format

An exercise is plain JSON, so it can be stored in a database or produced by a backend.

```json
{
  "id": "like-button",
  "language": "js",
  "files": {
    "App.tsx": { "code": "export default function App() { return <button>Like</button>; }" },
    "api.ts": { "code": "export const posts = [];", "readOnly": true }
  },
  "entry": "App.tsx",
  "checks": {
    "App.test.tsx": "import { it, expect } from \"drillbox:test\";\nimport { render, screen } from \"@testing-library/react\";\nimport App from \"./App\";\n\nit(\"shows the button\", () => {\n  render(<App />);\n  expect(screen.getByRole(\"button\")).toBeInTheDocument();\n});\n"
  },
  "options": { "react": true }
}
```

| Field      | Required | Meaning                                                                                                                          |
| ---------- | -------- | -------------------------------------------------------------------------------------------------------------------------------- |
| `id`       | yes      | Any string of 1 to 200 characters                                                                                                |
| `language` | yes      | One of `js`, `python`, `java`, `c`, `cpp`, `csharp`, `rust`, `swift`, `go`. Only `js` has an adapter today                       |
| `files`    | yes      | The learner's files, by path. Each has `code` and optional `readOnly` and `hidden` flags. 1 to 50 files                          |
| `entry`    | yes      | The file the preview renders. Must be a key of `files`                                                                           |
| `checks`   | yes      | Check files, by path, as source text. At most 20; may be empty (`{}`). A check file may not have the same path as a learner file |
| `options`  | no       | Adapter settings. `{ "react": true }` turns on the React pack                                                                    |

Rules:

- Unknown keys are rejected at every level.
- Paths are relative, use `/`, and contain only letters, digits, `_`, `.` and `-`. No
  segment may start with `.` or `-`. Examples: `App.tsx`, `src/api.ts`.
- Supported file types are `.tsx`, `.ts`, `.jsx` and `.js` (lower case only).
- `readOnly` and `hidden` are hints for your editor. The [Workspace](#workspace) follows
  them (no tab for a hidden file, no editing of a read-only one), but the engine does not
  enforce them: every file, hidden or not, is sent into the frame.
- Files import each other by relative path (`./api`). The extension may be left out; the
  loader tries the exact path, then `.tsx`, `.ts`, `.jsx`, `.js`. A folder's `index` file is
  not found automatically.
- Packages from npm are not available. With the React pack on, files can import `react`,
  `react-dom`, `react-dom/client`, `react/jsx-runtime`, `react/jsx-dev-runtime` and
  `@testing-library/react`. Check files can also import `drillbox:test`. Any other bare
  import fails with `Module '<spec>' is not available in the sandbox`; a missing relative
  file fails with `Cannot find module '<spec>' imported from <file>`.
- The preview needs the React pack: it renders the entry file's default export as a React
  component.

Validate an exercise with `parseExercise(input)` from `drillbox/schema`. It never throws:
it returns `{ ok: true, exercise }` or `{ ok: false, issues }`, with one
`"<path>: <message>"` string per problem. `run` validates again before anything reaches the
frame. Other languages and tools can validate against `schema/exercise.schema.json`. That
JSON Schema does not express the file counts or the cross-field rules (`entry` must name a
file; check paths must differ from file paths), so run `parseExercise` as well.

### Writing checks

Check files import their test functions from `drillbox:test`. The check runner inside the
frame supports:

- `describe`, `it` (including `async` tests), `beforeEach` and `afterEach`;
- `expect` with the chai and `@vitest/expect` matchers (the ones vitest uses), plus the
  jest-dom DOM matchers such as `toBeInTheDocument` when the React pack is on.

Each test body has a time limit (3 s by default). Each `beforeEach` and `afterEach` hook
gets its own full limit too, so in the worst case one test takes the limit multiplied by
the number of its hooks plus one. A hook that runs too long fails the test with the same
message as a slow body, `Test timed out in <ms>ms`.

The runner does **not** support `expect.assertions` or `expect.hasAssertions`; `it.skip`,
`it.only` or `it.each`; cleanup functions returned from `beforeEach`; `expect.soft` or
`expect.poll`; fake timers; or module mocking. Checks that use any of these pass under
vitest and fail in the browser, so leave them out. Exercises control time and data through
their own files (for example a fake API file).

To run the same check files under vitest (for example in your CI), alias `drillbox:test`
to `drillbox/vitest` in your vitest config, and add
`node_modules/drillbox/types/drillbox-test.d.ts` to your `tsconfig.json` so TypeScript
knows the module. This repository tests the shim's exports and the type declaration, not
this alias set-up.

```ts
// vitest.config.ts
import { defineConfig } from "vitest/config";
export default defineConfig({ resolve: { alias: { "drillbox:test": "drillbox/vitest" } } });
```

## Limits

The values live in `src/constants.ts` and are exported from `drillbox`.

| Constant             | Value  | What it limits                                                                           |
| -------------------- | ------ | ---------------------------------------------------------------------------------------- |
| `TEST_TIMEOUT_MS`    | 3000   | Time for one test body, and separately for each `beforeEach` or `afterEach` hook         |
| `LOOP_BUDGET_MS`     | 1500   | Time code may spend in loops without yielding to the browser before `loop ran too long`  |
| `PING_INTERVAL_MS`   | 1000   | How often the host asks the frame whether it is still responding                         |
| `PONG_TIMEOUT_MS`    | 3500   | How long the frame may go without answering before the run resolves `timeout`            |
| `READY_TIMEOUT_MS`   | 5000   | Time for a new frame to report that it is ready                                          |
| `RUN_TIMEOUT_MS`     | 60000  | Time for a whole run                                                                     |
| `MAX_FILES`          | 50     | Learner files per exercise                                                               |
| `MAX_CHECK_FILES`    | 20     | Check files per exercise                                                                 |
| `MAX_FILE_CHARS`     | 200000 | Characters in one file                                                                   |
| `MAX_TEXT_CHARS`     | 2000   | Characters in one text field coming back from the frame; longer text is clipped          |
| `MAX_CONSOLE_EVENTS` | 200    | Console messages per run; after that the frame sends one "truncated" warning and no more |
| `MAX_LIST_ENTRIES`   | 100    | Entries in a list coming back from the frame (diagnostics, a check's suite names)        |
| `MAX_RESULTS`        | 500    | Check results the host keeps per run; later ones are dropped                             |
| `MAX_DIAGNOSTICS`    | 200    | Compile diagnostics the host keeps per run; later ones are dropped                       |

Notes:

- The six time limits can be changed per sandbox, for example
  `createSandbox({ container, frameUrl, limits: { testTimeoutMs: 5000 } })`. The engine
  checks them: a value that is not a finite number above zero is replaced by that limit's
  default; `pingIntervalMs`, `readyTimeoutMs` and `runTimeoutMs` below 100 become 100;
  and `pongTimeoutMs` is raised to `loopBudgetMs + 2 * pingIntervalMs` when it is smaller,
  so a frame busy in one guarded loop slice is not taken for a frozen one. The watchdog
  counts `pongTimeoutMs` in whole ping intervals: with the defaults, four missed pings
  (`ceil(3500 / 1000)`). The frame then clamps `testTimeoutMs` to 100–30000 and
  `loopBudgetMs` to 100–10000.
- The host also caps what it keeps and forwards for one run: at most `MAX_RESULTS` (500)
  check results and `MAX_DIAGNOSTICS` (200) diagnostics (a `compile-error` event is
  trimmed to the diagnostics kept, and at most one with none is passed on), and
  `MAX_CONSOLE_EVENTS + 1` (201) `console` and `runtime-error` events, a kept preview's
  later output included. Nothing a cap drops reaches `onEvent`.
- Text that comes back from the frame (messages, console lines, check and file names) is
  clipped to 2000 characters. The frame cuts diagnostics and suite lists to 100 entries
  before sending; the host drops any message with a longer list.
- The exercise `id` is limited to 200 characters.

## Threat model

The learner's code is code the host page did not write, so drillbox treats it as
untrusted.

**What it protects.** drillbox protects the host page, its storage and its cookies from
exercise code, and blocks the network requests the browser tests probed from it (`fetch`,
an image, a WebSocket, a beacon, a stylesheet and a script). Other channels, for example
WebRTC, were not tested, and navigation is not blocked (see below).

- The frame is `<iframe sandbox="allow-scripts">` without `allow-same-origin`. The browser
  gives it an opaque origin (`null`), so its code cannot read the host page's DOM,
  `localStorage` or cookies. The browser tests confirm this in Chromium, Firefox and
  WebKit.
- The frame page refuses to start unless it is sandboxed. Its runtime checks that its own
  origin is opaque (`self.origin === "null"`); otherwise it logs
  `drillbox: refusing to start outside a sandboxed frame` and does nothing else (no
  `ready`, no message listener, no code run). The reason: `frame.html` is served from your
  site, so any other page can embed it in a plain `<iframe>` without `sandbox` (or open it
  directly) and post code to it, and that code would then run with your site's origin
  and could read its storage and cookies. The `sandbox allow-scripts` response header
  (see [Usage](#usage)) is a second layer: with it the browser sandboxes the page however
  it is embedded. The browser tests embed the page without the attribute, with and
  without the header, in Chromium, Firefox and WebKit.
- The frame page's Content-Security-Policy is
  `default-src 'none'; script-src 'unsafe-inline' 'unsafe-eval'; style-src 'unsafe-inline'; img-src data: blob:; font-src data:; connect-src 'none'; form-action 'none'; base-uri 'none'`.
  The browser tests probed `fetch`, an image, a WebSocket, a beacon, a stylesheet and a
  script from inside the frame; all of them were blocked in Chromium, Firefox and WebKit.
- No secret, token, cookie or host storage value is sent into the frame. The engine sends
  only the exercise and two time limits. Do not put secrets in exercise files.
- Every message crossing the frame boundary is validated. The host accepts messages only
  from its own frame's window and rebuilds each one from known fields; the frame accepts
  messages only from its parent. Malformed messages are dropped.

**What it does not protect against.**

- It does not defend against a browser sandbox escape: a browser bug that lets code break
  out of the iframe sandbox. Keep browsers up to date.
- The hidden checks are hidden from the editor, not from code running in the frame. The
  engine sends the whole exercise, check files included, into the frame in both modes. The
  checks also run in the same JavaScript environment as the learner's code, so that code
  can read them and can interfere with their results. Treat results as feedback for the
  learner, not as proof for grading.
- A frame can navigate itself away (for example by setting `location.href`). The
  Content-Security-Policy does not block that, and the address it navigates to can carry
  data such as the exercise files. After navigating, the frame stops answering and the run
  times out. A preview whose run has completed has no watchdog, so a preview that navigates
  away just shows the other page. The browser tests do not cover this case.

**Runaway code.** The JS adapter inserts a loop guard into every loop. Once code has spent
1.5 s in loops without yielding to the browser, the guard throws `loop ran too long`,
which fails that check. The engine also runs a watchdog: it pings the frame every second
and resolves the run `timeout` after about 4 s without an answer (`PONG_TIMEOUT_MS`,
3.5 s, rounded up to whole ping intervals: four missed pings). The watchdog counts only
time during which the host page itself was running. Runaways that are not loops are
outside the guard's reach too: catastrophic regular-expression backtracking, a single huge
call into a built-in function, or deep synchronous recursion that does not overflow the
stack.

How this behaves depends on the browser:

- In Firefox, Safari (WebKit) and headless Chromium the frame shares the host page's
  thread, so the whole page stalls while a guarded loop runs. Each guarded loop stretch
  runs for up to 1.5 s (`LOOP_BUDGET_MS`), and the checks of one run can stall the page
  back to back. In the browser tests, with a four-check exercise where every check loops,
  the longest stalls of the host page were about 3 s in Chromium and Firefox and about
  1.5 s in WebKit, and the run took about 6 s in total. A runaway the guards cannot see
  (code built to evade them, for example through `new Function`, or one of the non-loop
  cases above) freezes the whole page, and nothing on the page can report it. The
  browser's own "page unresponsive" prompt is the only way out.
- In Chromium started with `--site-per-process` the frame got its own process, and the
  engine detected the freeze and resolved `timeout`. Desktop Chrome is expected to behave
  the same way, because it isolates sandboxed frames, but it was not tested itself. The
  stuck frame cannot be replaced. By design, the next run in the same page then resolves
  `unavailable` because the new frame never reports that it is ready; the engine's unit
  tests cover this with a fake transport, while the browser tests saw only the demo's
  status line, which shows the same message for `timeout` and `unavailable`.

A frozen sandbox therefore needs a page reload, and a reload may not be enough: in the
browser tests a reload did not recover the sandbox, so the learner may have to close the
tab and open the page again. Hosts must keep the learner's code outside the frame (in the
host page's state or its storage) and should tell the learner to reload or reopen the page
when a run resolves `timeout` or `unavailable`.

A preview that stays on screen after its run has completed has no watchdog.

## Known limitations

- No type checking. TypeScript types are removed, not checked.
- The frame runs React's development build, because Testing Library needs it. The frame
  page with the React pack is about 1.18 MB of scripts (about 490 KB without it).
- No npm packages inside exercises; only the modules listed under
  [Exercise format](#exercise-format).
- The host-side engine bundles zod: about 750 KB unminified, largely locale data. In the
  demo page, under its own Content-Security-Policy, Chromium logged one policy message
  from zod's feature probe in the console; validation still worked.
- A host bundle that uses the workspace also carries CodeMirror: the demo's is about 1.12 MB
  (1 MB here is a million bytes). Its minified `demo/dist/app.js`, which holds React, CodeMirror, the
  engine, zod and the demo page, is 1,117,264 bytes (measured on 2026-11-22).
  A host that bundles only the workspace is smaller: a minimal host page rendering
  `<Workspace>`, built the same way, was 1,113,817 bytes (about 1.11 MB).
- Only the `js` language has an adapter. Python and the remote adapter for compiled
  languages are not built yet.

## Contributing and security

See [CONTRIBUTING.md](CONTRIBUTING.md) to build and test the project, and
[SECURITY.md](SECURITY.md) to report a vulnerability.

## License

MIT. The frame page bundles third-party libraries; after a build their notices are in
`dist/frame-chunks/THIRD-PARTY-LICENSES.txt`, which ships in the package.
